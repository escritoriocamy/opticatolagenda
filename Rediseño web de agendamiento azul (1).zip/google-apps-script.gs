/* ======================================================
   CONSULTORIO OFTALMOLÓGICO — recepción de reservas
   Pegar TODO este código en Apps Script de la planilla.
   ====================================================== */

const HOJA = 'Reservas';
const CLAVE = 'consultorio2026';   // clave para ver las reservas desde la web

function doPost(e) {
  const datos = JSON.parse(e.postData.contents);
  const hoja = obtenerHoja();
  hoja.appendRow([
    datos.enviado, datos.nombre, datos.cedula, datos.nacimiento,
    datos.oftalmologo, datos.servicio, datos.fecha, datos.hora,
    datos.diabetes, datos.origen
  ]);
  return json({ ok: true });
}

function doGet(e) {
  if (!e || !e.parameter || e.parameter.clave !== CLAVE) {
    return json({ ok: false, error: 'clave incorrecta' });
  }
  const hoja = obtenerHoja();
  const filas = hoja.getDataRange().getValues().slice(1);
  const reservas = filas.map(function (f) {
    return {
      enviado: String(f[0]), nombre: f[1], cedula: f[2], nacimiento: String(f[3]),
      oftalmologo: f[4], servicio: f[5], fecha: String(f[6]), hora: f[7],
      diabetes: f[8], origen: f[9]
    };
  });
  return json({ ok: true, reservas: reservas });
}

function obtenerHoja() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let hoja = ss.getSheetByName(HOJA);
  if (!hoja) {
    hoja = ss.insertSheet(HOJA);
    hoja.appendRow(['Enviado', 'Nombre y apellido', 'Cédula', 'Fecha de nacimiento',
                    'Oftalmólogo', 'Servicio', 'Día', 'Hora', 'Diabetes', 'Origen']);
  }
  return hoja;
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
